package com.example.jogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class IniciarJogo extends AppCompatActivity {
private TextView txtNome, txtNomeJogador;


private Jogador jogador = new Jogador();
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_jogo);
        getSupportActionBar().hide();

        txtNome = findViewById(R.id.txtNomeInicio);
        txtNomeJogador = findViewById(R.id.txtNomeJogador);


        Bundle args = getIntent().getExtras();
        String nome = args.getString("chave_usuario");
        txtNome.setText("Olá "+nome+", seja bem vinda(o)");
        txtNomeJogador.setText("Você será o jogador 1!");

    }

    public void IniciarJogo(View view) {
        Intent intent = new Intent(this,Jogo.class);
        startActivity(intent);
    }

    public void voltarInicio(View view) {
        Intent it = new Intent(this,MainActivity.class);
        startActivity(it);
    }
}