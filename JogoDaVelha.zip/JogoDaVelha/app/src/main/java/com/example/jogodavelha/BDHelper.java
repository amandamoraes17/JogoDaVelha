package com.example.jogodavelha;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class BDHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "jogador.db";
    private static final String TABLE_NAME = "jogador";
    private static final String COLUM_ID = "id";
    private static final String COLUM_NOME = "nome";

    private static final String COLUM_EMAIL = "email";
    private static final String COLUM_USUARIO = "usuario";
    private static final String COLUM_SENHA = "senha";

    SQLiteDatabase db;

    private static final String TABLE_CREATE = "create table jogador " +
            "(id integer primary key autoincrement, nome text not null," +
            " email text not null, usuario text not null, senha text not null);";

    public BDHelper(Context context) {
        super(context, DATABASE_NAME, null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db=db;
    }

    public void insereJogador(Jogador jogador){
        db=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUM_NOME, jogador.getNome());
        values.put(COLUM_EMAIL,jogador.getEmail());
        values.put(COLUM_USUARIO,jogador.getUsuario());
        values.put(COLUM_SENHA, jogador.getSenha());

        db.insert(TABLE_NAME,null,values);
        db.close();
    }

    public String buscarSenha(String usuario){
        db = this.getReadableDatabase();
        String query = "select usuario, senha from " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String a,b;
        b="não encontrado";
        if(cursor.moveToFirst()){
            do{
                a=cursor.getString(0);
                if(a.equals(usuario)){
                    b=cursor.getString(1);
                    break;
                }
            }while (cursor.moveToNext());
        }
        return b;
    }


    public long alterarJogador(Jogador jogador){
        long retornoBD;
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUM_NOME,jogador.getNome());
        values.put(COLUM_EMAIL,jogador.getEmail());
        values.put(COLUM_USUARIO, jogador.getUsuario());
        values.put(COLUM_SENHA,jogador.getSenha());
        String[] args = {String.valueOf(jogador.getNome())};
        retornoBD=db.update(TABLE_NAME,values,COLUM_NOME+"=?",args);
        db.close();
        return retornoBD;
    }


    @Override
    public void onUpgrade(SQLiteDatabase bd, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS "+TABLE_NAME;
        bd.execSQL(query);
        this.onCreate(bd);
    }
}
