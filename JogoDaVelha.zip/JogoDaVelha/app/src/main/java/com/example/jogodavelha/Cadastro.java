package com.example.jogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Cadastro extends AppCompatActivity {
private EditText edtNome, edtEmail, edtUsuario,edtSenha, edtSenhaConfirmacao;
private Button btnCadastra;
    BDHelper helper = new BDHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        getSupportActionBar().hide();

        edtNome = findViewById(R.id.edtNome);
        edtEmail = findViewById(R.id.edtEmail);
        edtUsuario = findViewById(R.id.edtUsuario_cadastro);
        edtSenha = findViewById(R.id.edtSenha_cadastro);
        edtSenhaConfirmacao = findViewById(R.id.edtSenhaConfirmacao);
        btnCadastra = findViewById(R.id.btnCadastra);
        Bundle args = getIntent().getExtras();
        if(args != null){
            btnCadastra.setText("ALTERAR");
            String nome = args.getString("ch_nome");
            String email = args.getString("ch_email");
            String usuario = args.getString("ch_usuario");
            String senha = args.getString("ch_senha");

            edtNome.setText(nome);
            edtEmail.setText(email);
            edtUsuario.setText(usuario);
            edtSenha.setText(senha);


        }
        else{
            btnCadastra.setText("CADASTRAR");
        }
    }


    public void cadastrar_novo(View view) {
    String nome = edtNome.getText().toString();
    String email = edtEmail.getText().toString();
    String usuario = edtUsuario.getText().toString();
    String senha = edtSenha.getText().toString();
    String senhaConfirmacao = edtSenhaConfirmacao.getText().toString();
    if(nome.isEmpty() || email.isEmpty()||usuario.isEmpty()||senha.isEmpty()){
        Toast toast = Toast.makeText(Cadastro.this,
                "Preecher todos os campos", Toast.LENGTH_SHORT);
        toast.show();
    }
    if(!senha.equals(senhaConfirmacao)) {
        Toast toast = Toast.makeText(Cadastro.this,
                "Senha difere da confirmação!", Toast.LENGTH_SHORT);
        toast.show();
        edtSenha.setText("");
        edtSenhaConfirmacao.setText("");
    }else {
        Jogador j = new Jogador(nome,email,usuario,senha);
        if(btnCadastra.getText().toString().equalsIgnoreCase("ALTERAR"));
        helper.insereJogador(j);
        helper.close();
        Toast toast = Toast.makeText(Cadastro.this,
                "Operação realizada com suceso!",Toast.LENGTH_SHORT);
        toast.show();
        finish();

    }

    }

    public void cancelar(View view) {
        Intent it = new Intent(this,MainActivity.class);
        startActivity(it);
    }
}