package com.example.jogodavelha;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.Bundle;

import android.view.View;

import android.widget.EditText;

import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    BDHelper helper = new BDHelper(this);
    private EditText edtUsuario;
    private EditText edtSenha;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        edtUsuario = findViewById(R.id.edtUsuario);
        edtSenha = findViewById(R.id.edtSenha);



    }

    public void login(View view) {
        String usuario = edtUsuario.getText().toString();
        String senha = edtSenha.getText().toString();
        String senhaConf = helper.buscarSenha(usuario);
        if(usuario.isEmpty() || senha.isEmpty()){
            Toast toast = Toast.makeText(MainActivity.this,"Preecher todos os campos",Toast.LENGTH_SHORT);
            toast.show();
        }
        if(senha.equals(senhaConf)){
            Intent intent = new Intent(this,IniciarJogo.class);
            intent.putExtra("chave_usuario",usuario);
            startActivity(intent);
        }else{
            Toast toast = Toast.makeText(MainActivity.this,
                    "Usuario não encontrado", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void cadastrar(View view) {
        Intent it = new Intent(this,Cadastro.class);
        startActivity(it);
    }

}