package com.example.jogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Jogo extends AppCompatActivity implements View.OnClickListener {
    private TextView txtPlacar_jogador2, txtPlacar_jogador1, txtStatusJogo;

    private Button[] btn = new Button[9];
    private Button btnReniciarJogo;
    private int numJogadas, placarJogador1, placarJogador2;
    private boolean jogador;
    private int[] jogadas = {0, 0, 0, 0, 0, 0, 0, 0, 0,};
    private int[][] vitorias = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogo);
        getSupportActionBar().hide();

        txtPlacar_jogador1 = findViewById(R.id.txtPlacar_jogador1);
        txtPlacar_jogador2 = findViewById(R.id.txtPlacar_jogador2);
        txtStatusJogo = findViewById(R.id.txtStatusJogo);

        btnReniciarJogo = findViewById(R.id.btnReniciarJogo);


        for (int i = 0; i < btn.length; i++) {
            int id = getResources().getIdentifier("btn_" + i, "id", getPackageName());
            btn[i] = findViewById(id);
            btn[i].setOnClickListener(this);
        }
        jogador = true;
        placarJogador1 = 0;
        placarJogador2 = 0;
        numJogadas = 1;
        btnReniciarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                placarJogador1 = 0;
                placarJogador2 = 0;
                reiniciarJogo();
                exibirPlacar();
            }
        });
    }

    @Override
    public void onClick(View view) {


        if (!((Button) view).getText().toString().equals("")) {
            return;
        }
        int numBtn = Integer.parseInt(view.getResources().getResourceEntryName(view.getId()).substring(4, 5));
        if (jogador) {
            ((Button) view).setText("X");
            jogadas[numBtn] = 1;
        } else {
            ((Button) view).setText("O");
            jogadas[numBtn] = 2;
        }

        if (venceu()) {
            if (jogador) {
                placarJogador1++;
                Toast.makeText(view.getContext(), "Jogador 1 venceu", Toast.LENGTH_LONG).show();
            } else {
                placarJogador2++;
                Toast.makeText(view.getContext(), "Jogador 2 venceu", Toast.LENGTH_LONG).show();
            }
            exibirPlacar();
            reiniciarJogo();

        } else if (numJogadas == 9) {
            Toast.makeText(view.getContext(), "Deu Velha", Toast.LENGTH_LONG).show();
            reiniciarJogo();

        } else {
            numJogadas++;
            jogador = !jogador;
        }


    }

    private void exibirPlacar() {
        txtPlacar_jogador1.setText(""+placarJogador1);
        txtPlacar_jogador2.setText(""+ placarJogador2);

        if(placarJogador1 > placarJogador2){
            txtStatusJogo.setText("Jogador 1 está ganhando");
        }else if(placarJogador2 > placarJogador1){
            txtStatusJogo.setText("Jogador 2 está ganhando");
        }else{
            txtStatusJogo.setText("O jogo está empatado");
        }
    }


    private boolean venceu() {
        boolean result = false;

        for (int[] jogadasEfetuadas : vitorias) {
            if (jogadas[jogadasEfetuadas[0]] == jogadas[jogadasEfetuadas[1]] &&
                    jogadas[jogadasEfetuadas[1]] == jogadas[jogadasEfetuadas[2]] &&
                    jogadas[jogadasEfetuadas[0]] != 0) {
                result = true;
            }
        }

        return result;
    }


    private void reiniciarJogo() {
        numJogadas = 1;
        jogador = true;
        for (int i = 0; i <btn.length;i++){
            btn[i].setText("");
            jogadas[i] = 0;
        }
    }

    public void sair(View view) {
        finish();
    }
}